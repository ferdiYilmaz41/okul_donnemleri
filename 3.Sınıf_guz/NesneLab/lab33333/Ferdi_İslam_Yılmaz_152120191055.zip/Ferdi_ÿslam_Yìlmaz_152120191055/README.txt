152120191055 Ferdi İslam Yılmaz
{hesaplama kısmını yaptı}



152120191067 Hüseyin Emir Leylek
{infixi postfixe çevirme kısmını yaptı}

en son hataları birlikte inceleyip son haline getirdik