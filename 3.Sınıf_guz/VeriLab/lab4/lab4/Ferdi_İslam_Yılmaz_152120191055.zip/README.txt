Ferdi:constructor, destructor, AddFront,AddRear
Emir:RemoveFront, RemoveRear, Front, Rear
son düzenleme beraber yapılmıştır.