#include "Prj1header.h"

int main(int argc, char *argv[])
{
    pid_t child_pid;
    int child_status;
    
    if(argc!=4)/*4 because the executables name string is on argc*/
    {
        printf("Error: Inputs-> sourceFile destFile blockSize\n");
        exit(-1);
    }
    
    int bufferSize = atoi(argv[3]);
    if (bufferSize<=0)
    {
        printf("Error: Wrong buffer size\n");
    }
    
    child_pid = fork();
    
    switch (child_pid) {
        case -1:
            perror("fork");
            exit(1);
        case 0:
            execl("./MakeCopy", "MakeCopy", argv[1], argv[2], argv[3], NULL);
            perror("execl() failed!");
        default:
            wait(&child_status);
    }
    
    exit(0);
    
}
