#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <inttypes.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>

/* gcc -lpthread -o s semaphore.c -Wno-deprecated */
sem_t mutex;
void* thread1(void* arg) {
	//wait
	sem_wait(&mutex);
	printf("\nThread 1: Entered..\n");
	//critical section
	sleep(4);
	//signal
	printf("\nThread 1: Exiting...\n");
	sem_post(&mutex);
}

void* thread2(void* arg) {
	//wait
	sem_wait(&mutex);
	printf("\nThread 2: Entered..\n");
	//critical section
	sleep(4);
	//signal
	printf("\nThread 2: Exiting...\n");
	sem_post(&mutex);
}

int main() {
sem_init(&mutex, 0, 1);
pthread_t t1,t2;
pthread_create(&t1,NULL,thread1,NULL);
sleep(2);
pthread_create(&t2,NULL,thread2,NULL);
pthread_join(t1,NULL);
pthread_join(t2,NULL);
sem_destroy(&mutex);
return 0;
}
