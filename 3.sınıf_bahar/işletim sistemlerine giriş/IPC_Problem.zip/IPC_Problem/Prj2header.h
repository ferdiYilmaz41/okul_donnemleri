#ifndef PRJ2HEADER_H_
#define PRJ2HEADER_H_

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <inttypes.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>

#endif /*PRJ2HEADER_H_*/

